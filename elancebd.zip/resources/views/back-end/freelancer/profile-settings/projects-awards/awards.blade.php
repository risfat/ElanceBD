<freelancer_award 
    :server_errors="'{{ trans('lang.all_required') }}'"
    :ph_award_title = "'{{ trans('lang.ph_award_title') }}'">
</freelancer_award>