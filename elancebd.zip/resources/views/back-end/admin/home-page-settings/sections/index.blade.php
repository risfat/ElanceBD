<div class="wt-tabscontenttitle">
    <h2>{{ trans('lang.start_as_sec') }}</h2>
</div>
    @include('back-end.admin.home-page-settings.sections.background-image')
    @include('back-end.admin.home-page-settings.sections.start-as')
<div class="wt-tabscontenttitle">
    <h2>{{ trans('lang.download_app_sec_settings') }}</h2>
</div>
@include('back-end.admin.home-page-settings.sections.download-app')