<aside id="wt-sidebar" class="wt-sidebar">
    <div class="wt-proposalsr">
        @include('front-end.jobs.sidebar.wt-jobproposals-widget')
        @include('front-end.jobs.sidebar.wt-qrcode-widget')
        @include('front-end.jobs.sidebar.wt-addtofavourite-widget')
    </div>
    @include('front-end.jobs.sidebar.wt-employerinfo-widget')
    @include('front-end.jobs.sidebar.wt-sharejob-widget')
    @include('front-end.jobs.sidebar.wt-reportjob-widget')
</aside>
