<div class="wt-tabscontenttitle">
    <h2>{{{ trans('lang.my_skills') }}}</h2>
</div>
<user_skills :ph_rate_skills="'{{ trans('lang.ph_rate_skills') }}'"></user_skills>