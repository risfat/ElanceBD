<freelancer_education
    :ph_job_title="'{{ trans('lang.ph_job_title') }}'"
    :ph_institute_title="'{{ trans('lang.ph_institute_title') }}'"
    :ph_desc="'{{ trans('lang.ph_desc') }}'"
    :ph_degree_title="'{{ trans('lang.ph_degree_title') }}'">
</freelancer_education>