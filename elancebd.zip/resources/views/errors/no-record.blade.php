<div class="wt-emptydata-holder">
    <div class="wt-emptydata">
        <div class="wt-emptydetails wt-empty-person">
        <img src="{{{ asset('/images/empty-images/no-record.png') }}}">
            <em>{{ trans('lang.no_record') }}</em>
        </div>
    </div>
</div>